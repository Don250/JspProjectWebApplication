package dao;

import java.util.List;
import model.Signup;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class SignupDao {

    public boolean register(Signup signup) {
        String message = "data saved successfully";
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(signup);
        tx.commit();
        session.close();

        return message != null;
    }

    public boolean Authentication(Signup signup) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        Query query = session.createQuery("FROM Signup si WHERE si.email=:email AND si.password=:password");
        query.setParameter("email", signup.getEmail());
        query.setParameter("password", signup.getPassword());
        Signup result = (Signup) query.uniqueResult();
        tx.commit();
        return result != null;
    }

    public List<Signup> getAllAccounts() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        List<Signup> list = session.createQuery("from si Signup si").list();
        session.close();
        return list;
    }

    public Signup FindByEmail(Signup signup) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Signup signup1 = (Signup) session.get(Signup.class, signup.getEmail());
        session.close();
        return signup1;
    }

}
