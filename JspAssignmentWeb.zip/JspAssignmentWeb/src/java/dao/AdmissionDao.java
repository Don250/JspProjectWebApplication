
package dao;

import java.util.List;
import model.Admission;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;


public class AdmissionDao {
    
    public boolean saveAddmission(Admission addmission){
       Session session=null;
       boolean message=false;
       try {
          
           session=HibernateUtil.getSessionFactory().openSession();
           Transaction txt=session.beginTransaction();
           session.save(addmission);
          txt.commit();
           session.close();
           message=Boolean.TRUE;
           return message;
       } catch (Exception e) {
           e.printStackTrace();
       }
       return message;
}
    
    public List< Admission> getAlladmission(){
        Session session=HibernateUtil.getSessionFactory().openSession();
       List< Admission>addmissionList=(List< Admission>) session.createQuery("From ad Admission ad").list();
        session.close();
        return addmissionList;
   }
    
    
    public void deleteById(Admission admission){
        Session s=HibernateUtil.getSessionFactory().openSession();
       Transaction tx = s.beginTransaction();
       s.delete(admission);
       tx.commit();
       s.close();
    }
     public void updateStudent(Admission admission){
         Session session = HibernateUtil.getSessionFactory().openSession();
         Transaction tx = session.beginTransaction();
         session.update(admission);
         tx.commit();
         session.close();
         
                 
     }
     public Admission finfById(String id){
         Session session =null;
         Admission result = null;
         try {
             Session s = HibernateUtil.getSessionFactory().openSession();
             Criteria criteria = session.createCriteria(Admission.class);
             criteria.add(Restrictions.eq(id, id));
             result= (Admission) criteria.uniqueResult();
                     
             
         } catch (HibernateException e) {
            
         }finally{
             if(session!= null){
                 session.close();
             }
         }
         return result;
     }
     
    
}
