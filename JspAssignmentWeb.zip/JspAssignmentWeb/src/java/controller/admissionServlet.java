//
//package controller;
//
//import dao.AdmissionDao;
//import java.io.ByteArrayOutputStream;
//import java.io.IOException;
//import java.io.InputStream;
//import java.io.PrintWriter;
//import java.util.logging.Level;
//import java.util.logging.Logger;
//import javax.mail.MessagingException;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.MultipartConfig;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.Part;
//import model.Admission;
//
//
//@MultipartConfig
//@WebServlet(name = "admissionServlet", urlPatterns = {"/admissionServlet"})
//public class admissionServlet extends HttpServlet {
//
//    /**
//     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
//     * methods.
//     *
//     * @param request servlet request
//     * @param response servlet response
//     * @throws ServletException if a servlet-specific error occurs
//     * @throws IOException if an I/O error occurs
//     */
//    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        response.setContentType("text/html;charset=UTF-8");
//        try (PrintWriter out = response.getWriter()) {
//            /* TODO output your page here. You may use following sample code. */
//            out.println("<!DOCTYPE html>");
//            out.println("<html>");
//            out.println("<head>");
//            out.println("<title>Servlet admissionServlet</title>");
//            out.println("</head>");
//            out.println("<body>");
//            out.println("<h1>Servlet admissionServlet at " + request.getContextPath() + "</h1>");
//            out.println("</body>");
//            out.println("</html>");
//        }
//    }
//
//    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
//    /**
//     * Handles the HTTP <code>GET</code> method.
//     *
//     * @param request servlet request
//     * @param response servlet response
//     * @throws ServletException if a servlet-specific error occurs
//     * @throws IOException if an I/O error occurs
//     */
//    @Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        processRequest(request, response);
//    }
//
//    /**
//     * Handles the HTTP <code>POST</code> method.
//     *
//     * @param request servlet request
//     * @param response servlet response
//     * @throws ServletException if a servlet-specific error occurs
//     * @throws IOException if an I/O error occurs
//     */
//    @Override
//    protected void doPost(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        Admission addmission = new Admission();
//        try {
//            Part diploma = request.getPart("diploma");
//            InputStream dipinput = diploma.getInputStream();
//            ByteArrayOutputStream bot = new ByteArrayOutputStream();
//            byte[] buffpdf = new byte[1024];
//            while (dipinput.read(buffpdf) != -1) {
//                bot.write(buffpdf);
//            }
//            pdfdip = bot.toByteArray();
//            addmission.setCertificate(pdfdip);
//
//            Part ppicture = request.getPart("picture");
//            InputStream imageInput = ppicture.getInputStream();
//            ByteArrayOutputStream bospicture = new ByteArrayOutputStream();
//            byte[] bytimg = new byte[1024];
//            while (imageInput.read(bytimg) != -1) {
//                bospicture.write(bytimg);
//            }
//            img = bospicture.toByteArray();
//            addmission.setImage(img);
//
//            addmission.setCertificate(pdfdip);
//            addmission.setNames(request.getParameter("names"));
//            addmission.setNid(Long.parseLong(request.getParameter("nationalID")));
//            addmission.setNationality(request.getParameter("nationality"));
//            addmission.setPhoneNUmber(Integer.parseInt(request.getParameter("phoneNumber")));
//            addmission.setDob(request.getParameter("dob"));
//            addmission.setEmail(request.getParameter("email"));
//            addmission.setGender(request.getParameter("gender"));
//            addmission.setQualification(request.getParameter("qualification"));
//            addmission.setFaculty(request.getParameter("faculty"));
//            addmission.setDpt(request.getParameter("department"));
//            AdmissionDao dao = new AdmissionDao();
//            boolean res = dao.saveAddmission(addmission);
//
//            if (res) {
//                 response.sendRedirect("dashboard.html");
////                String address = request.getParameter("email");
////                SendEmail email = new SendEmail(address, "ximgkmzusksjdwoq");
////                String Recipient = (address);
////                String subject = "CONFIRMATION Email";
////                String message = "Hello,Conglatulations your form was submitted successfuly";
////                try {
////                    email.sendEmail(Recipient, subject, message);
////                    response.sendRedirect("dashboard.html");
////                } catch (MessagingException ex) {
////                    Logger.getLogger(admissionServlet.class.getName()).log(Level.SEVERE, null, ex);
////                }
//
////                try {
////                    JavaMailUtil javaMailUtil = new JavaMailUtil();
////                    javaMailUtil.sendMail(request.getParameter("email"));
////                    response.sendRedirect("dashboard.html");
////                } catch (Exception e) {
////                    e.printStackTrace();
////                }
//
//            }
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
////        processRequest(request, response);
//    }
//
//    /**
//     * Returns a short description of the servlet.
//     *
//     * @return a String containing servlet description
//     */
//    @Override
//    public String getServletInfo() {
//        return "Short description";
//    }// </editor-fold>
//    byte[] pdfdip = new byte[1024];
//    byte[] img = new byte[1024];
//}
