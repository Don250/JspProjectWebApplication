
package model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Admission implements Serializable{
    @Id
    @GeneratedValue
    private String id;
    private String names;
    private String Nid;
    private String nationality;
    private String phoneNUmber;
    private String dob;
    private String email;
    private String gender;
    private String qualification;
    private String faculty;
    private String dpt;
    private byte[] image;
    private byte[] certificate;

    public Admission() {
    }

    public Admission(String id) {
        this.id = id;
    }

    public Admission(String names, String Nid, String nationality,String phoneNUmber, String dob, String email, String gender, String qualification, String faculty, String dpt,byte[] image,byte[] certificate) {
        this.names = names;
        this.Nid = Nid;
        this.nationality = nationality;
        this.phoneNUmber = phoneNUmber;
        this.dob = dob;
        this.email = email;
        this.gender = gender;
        this.qualification = qualification;
        this.faculty = faculty;
        this.dpt = dpt;
        this.image = image;
        this.certificate = certificate;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNames() {
        return names;
    }

    public void setNames(String names) {
        this.names = names;
    }

    public String getNid() {
        return Nid;
    }

    public void setNid(String  Nid) {
        this.Nid = Nid;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String  getPhoneNUmber() {
        return phoneNUmber;
    }

    public void setPhoneNUmber(String  phoneNUmber) {
        this.phoneNUmber = phoneNUmber;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }

    public String getDpt() {
        return dpt;
    }

    public void setDpt(String dpt) {
        this.dpt = dpt;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public byte[] getCertificate() {
        return certificate;
    }

    public void setCertificate(byte[] certificate) {
        this.certificate = certificate;
    }  
    
}
