/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import dao.AdmissionDao;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import model.Admission;
import sun.rmi.server.UnicastRef;

/**
 *
 * @author HP
 */
public class AdmissionInterfaceImp extends UnicastRemoteObject implements AdmissionInterface{
    public  AdmissionInterfaceImp()throws RemoteException{
        super();
    }
    AdmissionDao dao=new AdmissionDao();

    @Override
    public boolean saveStudent(Admission admission) throws RemoteException {
       return dao.saveAddmission(admission);
    
    }
    



    @Override
    public List<Admission> getAllStudent() throws RemoteException {
        return dao.getAlladmission();
    }

  
    @Override
    public void updateStudent(Admission admission) {
        dao.updateStudent(admission);
    }

    @Override
    public void deleteStudent(Admission admission) {
      dao.deleteById(admission);
    }

    @Override
    public Admission findById(String id) throws RemoteException {
       return dao.finfById(id);
    }

   
   
   
}
