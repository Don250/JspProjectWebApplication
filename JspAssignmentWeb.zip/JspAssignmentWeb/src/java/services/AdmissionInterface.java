/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import model.Admission;

/**
 *
 * @author DonGate
 */
public interface AdmissionInterface extends Remote{
    public  boolean saveStudent(Admission admission)throws RemoteException;
    public List<Admission> getAllStudent()throws RemoteException;
    public void deleteStudent(Admission admission)throws  RemoteException;
    public void updateStudent(Admission admission)throws RemoteException;
    public  Admission findById( String id)throws RemoteException;
    
    
}
