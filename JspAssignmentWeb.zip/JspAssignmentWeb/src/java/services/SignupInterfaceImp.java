/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import dao.SignupDao;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import model.Signup;

/**
 *
 * @author HP
 */
public class SignupInterfaceImp extends UnicastRemoteObject implements SignupInterface{

    public SignupInterfaceImp() throws RemoteException {
        super();
    }
    SignupDao dao=new SignupDao();

    @Override
    public boolean registerAccount(Signup signup) throws RemoteException {
       return dao.register(signup);
    }

    @Override
    public boolean Authentication(Signup signup) throws RemoteException {
        return dao.Authentication(signup);
    }

    @Override
    public List<Signup> getAllAccounts() throws RemoteException {
       return dao.getAllAccounts();
    }
    
}
