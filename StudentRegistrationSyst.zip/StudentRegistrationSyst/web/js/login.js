/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


var  isemailvalid=true;
var ispassvalid=true;

function validation(){
    if(document.getElementById("email").value==""){
        isemailvalid=false;
        document.getElementById("emailError").innerHTML="Please fill up field with your email";
        document.getElementById("emailError").style.color="red";
          document.getElementById("hidde").innerHTML="";
    }else if(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(document.getElementById("email").value)==false){
        isemailvalid=false;
        document.getElementById("emailError").innerHTML="Invalid email, it must contain @ character.";
        document.getElementById("emailError").style.color="red";
          document.getElementById("hidde").innerHTML="";
    }else{
        isemailvalid=true;
        document.getElementById("emailError").innerHTML="";
          document.getElementById("hidde").innerHTML="";
    }

    if(document.getElementById("password").value==""){
        ispassvalid=false;
        document.getElementById("passError").innerHTML="Please provide your password."
        document.getElementById("passError").style.color="red";
          document.getElementById("hidde").innerHTML="";
    }else if(document.getElementById("password").value.length < 8){
        ispassvalid=false;
        document.getElementById("passError").innerHTML="invalid password,contains at list 8 characters.";
        document.getElementById("passError").style.color="red";
          document.getElementById("hidde").innerHTML="";
    }else{
        ispassvalid=true;
        document.getElementById("passError").innerHTML="";
        document.getElementById("hidde").innerHTML="";
    }


    if(isemailvalid==false||ispassvalid==false){
        return false;
          document.getElementById("hidde").innerHTML="";
    }else{
          document.getElementById("hidde").innerHTML="";
        return true;
    }
}