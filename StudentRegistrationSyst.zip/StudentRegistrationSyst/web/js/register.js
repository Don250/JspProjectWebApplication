/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


var isemailvalid = true;
var ispassvalid = true;
var isfnamevalid = true;
var islnamevalid = true;

function validate() {
    if (document.getElementById("fname").value == "") {
        isfnamevalid = false;

        document.getElementById("fnameError").innerHTML = "Please fill with first name";
        document.getElementById("fnameError").style.color = "red";
        document.getElementById("errors").innerHTML = "";

    } else {
        isfnamevalid = true;
        document.getElementById("fnameError").innerHTML = "";
        document.getElementById("errors").innerHTML = "";
    }


    if (document.getElementById("lname").value == "") {
        islnamevalid = false;
        document.getElementById("lnameError").innerHTML = "Please fill with your last name.";
        document.getElementById("lnameError").style.color = "red";
        document.getElementById("errors").innerHTML = "";
    } else {
        islnamevalid = true;
        document.getElementById("lnameError").innerHTML = "";
        document.getElementById("errors").innerHTML = "";
    }


    if (document.getElementById("email").value == "") {
        isemailvalid = false;
        document.getElementById("emailError").innerHTML = "Please fill up field with your email.";
        document.getElementById("emailError").style.color = "red";
        document.getElementById("errors").innerHTML = "";
    } else if (/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(document.getElementById("email").value) == false) {
        isemailvalid = false;
        document.getElementById("emailError").innerHTML = "Invalid email, it must contain @ character.";
        document.getElementById("emailError").style.color = "red";
        document.getElementById("errors").innerHTML = "";
    } else {
        isemailvalid = true;
        document.getElementById("emailError").innerHTML = "";
        document.getElementById("errors").innerHTML = "";
    }

    if (document.getElementById("password").value == "") {
        ispassvalid = false;
        document.getElementById("passError").innerHTML = "Please provide your password."
        document.getElementById("passError").style.color = "red";
        document.getElementById("errors").innerHTML = "";
    } else if (document.getElementById("password").value.length < 8) {
        ispassvalid = false;
        document.getElementById("passError").innerHTML = "invalid password,contains at list 8 characters.";
        document.getElementById("passError").style.color = "red";
        document.getElementById("errors").innerHTML = "";
    } else {
        ispassvalid = true;
        document.getElementById("passError").innerHTML = "";
        document.getElementById("errors").innerHTML = "";
    }


    if (isemailvalid == false || ispassvalid == false || isfnamevalid == false || islnamevalid == false) {
        document.getElementById("errors").innerHTML = "";
        return false;

    } else {
        document.getElementById("errors").innerHTML = "";
        return true;
    }
}