/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import model.Semester;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author ndagi
 */
public class SemesterDao {

    public boolean registerSemester(Semester semester) {
        boolean result = false;
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(semester);
        tx.commit();
        session.close();
        result = Boolean.TRUE;
        return result;
    }
    
    public Semester findSemester(String name){
          Session session = null;
        Semester semester1 = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Transaction tx = session.beginTransaction();
            Query query = session.createQuery("FROM Semester s WHERE s.name=:name");
            query.setParameter("name", name);
            semester1 = (Semester) query.uniqueResult();
            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return semester1;
    }
    
      
    public Semester findSemesterById(Integer id){
          Session session = null;
        Semester semester1 = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Transaction tx = session.beginTransaction();
            Query query = session.createQuery("FROM Semester s WHERE s.id=:id");
            query.setParameter("id", id);
            semester1 = (Semester) query.uniqueResult();
            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return semester1;
    }

    public List<Semester> getAllSemester() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        List<Semester> semester = session.createQuery("from Semester").list();
        tx.commit();
        session.close();
        return semester;
    }

    public void deleteSemester(Semester semester) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.delete(semester);
        tx.commit();
        session.close();
    }

    public void updateSemester(Semester semester) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction txt = session.beginTransaction();
        session.update(semester);
        txt.commit();
        session.close();
    }

}
