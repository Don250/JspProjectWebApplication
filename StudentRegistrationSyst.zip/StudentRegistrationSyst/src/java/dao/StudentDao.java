/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import model.Student;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author ndagi
 */
public class StudentDao {
     public boolean registerStudent(Student student) {
        boolean result = false;
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(student);
        tx.commit();
        session.close();
        result = Boolean.TRUE;
        return result;
    }
     
    public List<Student> getAllStudent() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        List<Student> student = session.createQuery("from Student").list();
        tx.commit();
        session.close();
        return student;
    }

    public void deleteStudent(Student student) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.delete(student);
        tx.commit();
        session.close();
    }

    public void updateStudent(Student student) {
        
      Session session = null; 
        try {
            session=HibernateUtil.getSessionFactory().openSession();
               Transaction tx=session.beginTransaction();
            session.update(student);
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            if (session!=null) {
                session.close();
            }
        }
    }
    
       public Student findStudent(String regNo) {
        Session session = null;
        Student student1 = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Transaction tx = session.beginTransaction();
            Query query = session.createQuery("FROM Student s WHERE s.regNo=:regNo");
            query.setParameter("regNo", regNo);
            student1 = (Student) query.uniqueResult();
            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return student1;
    }

       public Student findStudentById(Integer id) {
        Session session = null;
        Student student1 = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Transaction tx = session.beginTransaction();
            Query query = session.createQuery("FROM Student s WHERE s.id=:id");
            query.setParameter("id", id);
            student1 = (Student) query.uniqueResult();
            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return student1;
    }

    
}
