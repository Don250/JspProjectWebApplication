/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import model.Teacher;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author ndagi
 */
public class TeacherDao {
         public boolean registerTeacher(Teacher teacher) {
        boolean result = false;
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(teacher);
        tx.commit();
        session.close();
        result = Boolean.TRUE;
        return result;
    }
     
    public List<Teacher> getAllTeacher() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        List<Teacher> teachers = session.createQuery("from Teacher").list();
        tx.commit();
        session.close();
        return teachers;
    }

    public void deleteTeacher(Teacher teacher) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.delete(teacher);
        tx.commit();
        session.close();
    }

    public void updateTeacher(Teacher teacher) {     
        Session session = null;
     
        try {
            session=HibernateUtil.getSessionFactory().openSession();
               Transaction tx=session.beginTransaction();
            session.update(teacher);
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            if (session!=null) {
                session.close();
            }
        }
      
    }
    
       public Teacher findTeacher(String code) {
        Session session = null;
        Teacher teacher = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Transaction tx = session.beginTransaction();
            Query query = session.createQuery("FROM Teacher t WHERE t.code=:code");
            query.setParameter("code", code);
            teacher = (Teacher) query.uniqueResult();
            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return teacher;
    }
}
