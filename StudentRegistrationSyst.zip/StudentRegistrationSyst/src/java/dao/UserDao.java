/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.ArrayList;
import java.util.List;
import model.Users;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author ndagi
 */
public class UserDao {

    public boolean registerUser(Users user) {
        boolean message = false;
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(user);
        tx.commit();
        session.close();
        message = Boolean.TRUE;
        return message;
    }

    public boolean userAuthentication(Users user) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        Query query = session.createQuery("FROM Users u WHERE u.email=:email AND u.password=:password");
        query.setParameter("email", user.getEmail());
        query.setParameter("password", user.getPassword());
        Users result = (Users) query.uniqueResult();
        System.out.println(result);
        tx.commit();
        return result != null;
    }

    public void updateAccount(Users user) {

        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.update(user);
        tx.commit();
        session.close();
    }

    public List<Users> getAllAccounts(Users user) {

        Session session = null;
        List<Users> users = new ArrayList<>();
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            users = session.createQuery("from User").list();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }

            return users;
        }

    }

    public Users findByEmail(Users user) {
        Session session = null;
        Users user1 = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Transaction tx = session.beginTransaction();
            Query query = session.createQuery("FROM Users u WHERE u.email=:email");
            query.setParameter("email", user.getEmail());
            user1 = (Users) query.uniqueResult();
            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return user1;
    }

    public void deleteUser(Users user) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.delete(user);
        tx.commit();
        session.close();
    }
}
