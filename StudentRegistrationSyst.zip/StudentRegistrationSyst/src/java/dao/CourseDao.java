/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import model.Course;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author ndagi
 */
public class CourseDao {

    public boolean registerCourse(Course course) {
        boolean result = false;
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(course);
        tx.commit();
        session.close();
        result = Boolean.TRUE;
        return result;
    }

    public List<Course> getAllCourses() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        List<Course> courses = session.createQuery("from Course").list();
        tx.commit();
        session.close();
        return courses;
    }

    public Course findCourse(String courseCode) {
        Session session = null;
        Course course = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Transaction tx = session.beginTransaction();
          
            Query query = session.createQuery("FROM Course c WHERE c.courseCode=:courseCode");
            query.setParameter("courseCode", courseCode);
            course = (Course) query.uniqueResult();
            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return course;
    }

    public void deleteCourse(Course course) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.delete(course);
        tx.commit();
        session.close();
    }

    public void updateCourse(Course course) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction txt = session.beginTransaction();
        session.update(course);
        txt.commit();
        session.close();
    }
}
