/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import model.AcademicUnit;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author ndagi
 */
public class AcademicUnitDao {
       public boolean registerAcademicUnit(AcademicUnit academicUnit) {
        boolean result = false;
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(academicUnit);
        tx.commit();
        session.close();
        result = Boolean.TRUE;
        return result;
    }
     
    public List<AcademicUnit> getAllAcademicUnit() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        List<AcademicUnit> academicUnits = session.createQuery("from AcademicUnit").list();
        tx.commit();
        session.close();
        return academicUnits;
    }

    public void deleteAcademicUnit(AcademicUnit academicUnit) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.delete(academicUnit);
        tx.commit();
        session.close();
    }

    public void updateAcademicUnit(AcademicUnit academicUnit) {     
        Session session = null;
     
        try {
            session=HibernateUtil.getSessionFactory().openSession();
               Transaction tx=session.beginTransaction();
            session.update(academicUnit);
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            if (session!=null) {
                session.close();
            }
        }
      
    }
    
       public AcademicUnit findAcademicUnit(String academicCode) {
        Session session = null;
        AcademicUnit academicUnit = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Transaction tx = session.beginTransaction();
            Query query = session.createQuery("FROM AcademicUnit ac WHERE ac.academicCode = :academicCode");
            query.setParameter("academicCode", academicCode);
            academicUnit = (AcademicUnit) query.uniqueResult();
            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return academicUnit;
    }
    
}
