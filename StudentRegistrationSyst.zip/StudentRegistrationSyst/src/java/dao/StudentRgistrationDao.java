/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import model.StudentRegistration;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author ndagi
 */
public class StudentRgistrationDao {
      public boolean registerStudentRegistration(StudentRegistration studentRegistration) {
        boolean result = false;
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(studentRegistration);
        tx.commit();
        session.close();
        result = Boolean.TRUE;
        return result;
    }
     
    public List<StudentRegistration> getAllStudentRegistration() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        List<StudentRegistration> studentRegistrations = session.createQuery("from StudentRegistration").list();
        tx.commit();
        session.close();
        return studentRegistrations;
    }

    public void deleteStudentRegistration(StudentRegistration studentRegistration) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.delete(studentRegistration);
        tx.commit();
        session.close();
    }

    public void updateStudentRegistration(StudentRegistration studentRegistration) {     
        Session session = null;
     
        try {
            session=HibernateUtil.getSessionFactory().openSession();
               Transaction tx=session.beginTransaction();
            session.update(studentRegistration);
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            if (session!=null) {
                session.close();
            }
        }
      
    }
    
       public StudentRegistration findStudentRegistration(String studId) {
        Session session = null;
        StudentRegistration studentRegistration = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Transaction tx = session.beginTransaction();
            Query query = session.createQuery("FROM StudentRegistration std WHERE std.studId = :studId");
            query.setParameter("studId", studId);
            studentRegistration = (StudentRegistration) query.uniqueResult();
            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return studentRegistration;
    }
    
}
