/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import dao.StudentRgistrationDao;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import model.StudentRegistration;

/**
 *
 * @author ndagi
 */
public class StudentRegistrationInterfaceImp extends UnicastRemoteObject implements StudentRegistrationInterface{

    public StudentRegistrationInterfaceImp() throws RemoteException {
        super();
    }
      StudentRgistrationDao dao = new StudentRgistrationDao();
    

    @Override
    public boolean registerStudentRegistration(StudentRegistration studentRegistration) throws RemoteException {
      return dao.registerStudentRegistration(studentRegistration);
    }

    @Override
    public List<StudentRegistration> getAllStudentRegistration() throws RemoteException {
       return dao.getAllStudentRegistration();
    }

    @Override
    public void updateStudentRegistration(StudentRegistration studentRegistration) throws RemoteException {
        dao.updateStudentRegistration(studentRegistration);
    }

    @Override
    public StudentRegistration findStudentRegistration(String studId) throws RemoteException {
        return dao.findStudentRegistration(studId);
    }

    @Override
    public void deleteStudentRegistration(StudentRegistration studentRegistration) throws RemoteException {
       dao.deleteStudentRegistration(studentRegistration);
    }
    
}
