/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import dao.UserDao;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import model.Users;

/**
 *
 * @author ndagi
 */
public class UserInterfaceImp extends UnicastRemoteObject implements UserInterface{

    public UserInterfaceImp() throws RemoteException {
        super();
    }
    
    private UserDao dao=new UserDao();

    @Override
    public boolean registerUser(Users user) throws RemoteException {
       return dao.registerUser(user);
    }

    @Override
    public boolean userAuthentication(Users user) throws RemoteException {
      return dao.userAuthentication(user);
    }

    @Override
    public void updateAuccount(Users user) throws RemoteException {
      dao.updateAccount(user);
    }

    @Override
    public Users findByEmail(Users user) throws RemoteException {
        return dao.findByEmail(user);
    }

    @Override
    public void deleteUser(Users user) throws RemoteException {
     dao.deleteUser(user);
    }
    
}
