/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import dao.CourseDao;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import model.Course;

/**
 *
 * @author ndagi
 */
public class CourseInterfaceImp extends UnicastRemoteObject implements CourseInterface{

    public CourseInterfaceImp() throws RemoteException {
        super();
    }
    
    CourseDao dao=new CourseDao();

    @Override
    public boolean registerCourse(Course course) throws RemoteException {
     return dao.registerCourse(course);
    }

    @Override
    public List<Course> getAllCourses() throws RemoteException {
   return dao.getAllCourses();
    }

    @Override
    public void updateCourse(Course course) throws RemoteException {
        dao.updateCourse(course);
    }


    @Override
    public void deleteCourse(Course course) throws RemoteException {
    dao.deleteCourse(course);
    }

    @Override
    public Course findCourse(String courseCode) throws RemoteException {
      return dao.findCourse(courseCode);
    }
    
}
