/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import dao.AcademicUnitDao;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import model.AcademicUnit;

/**
 *
 * @author ndagi
 */
public class AcademicUnitInterfaceImp extends UnicastRemoteObject implements AcademicUnitInterface{

    public AcademicUnitInterfaceImp() throws RemoteException {
        super();
    }
    
    AcademicUnitDao dao = new AcademicUnitDao();
    @Override
    public boolean registerAcademicUnit(AcademicUnit academicUnit) throws RemoteException {
    return dao.registerAcademicUnit(academicUnit);
    }

    @Override
    public List<AcademicUnit> getAllAcademicUnit() throws RemoteException {
       return dao.getAllAcademicUnit();
    }

    @Override
    public void updateAcademicUnit(AcademicUnit academicUnit) throws RemoteException {
        dao.updateAcademicUnit(academicUnit);
    }

    @Override
    public AcademicUnit findAcademicUnit(String academicCode) throws RemoteException {
       return dao.findAcademicUnit(academicCode);
    }

    @Override
    public void deleteAcademicUnit(AcademicUnit academicUnit) throws RemoteException {
        dao.deleteAcademicUnit(academicUnit);
    }
    
}
