/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import dao.SemesterDao;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import model.Semester;

/**
 *
 * @author ndagi
 */
public class SemesterInterfaceImp extends UnicastRemoteObject implements SemesterInterface{

    public SemesterInterfaceImp() throws RemoteException {
        super();
    }
    
    SemesterDao dao=new SemesterDao();
  
    @Override
    public boolean registerCourse(Semester semester) throws RemoteException {
     return dao.registerSemester(semester);
    }

    @Override
    public List<Semester> getAllSemesters() throws RemoteException {
       return  dao.getAllSemester();
    }

    @Override
    public void updateSemester(Semester semester) throws RemoteException {
     dao.updateSemester(semester);
    }

    @Override
    public void deleteSemester(Semester semester) throws RemoteException {
     dao.deleteSemester(semester);
    }

    @Override
    public Semester findSem(String name) throws RemoteException {
      return dao.findSemester(name);
    }

    @Override
    public Semester findSemById(Integer id) throws RemoteException {
     return dao.findSemesterById(id);
    }
    
}
