/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import dao.StudentDao;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import model.Student;

/**
 *
 * @author ndagi
 */
public class StudentInterfaceImp extends UnicastRemoteObject implements StudentInterface{

    public StudentInterfaceImp() throws RemoteException {
        super();
    }
  
    StudentDao dao = new StudentDao();

    @Override
    public boolean registerCourse(Student student) throws RemoteException {
       return dao.registerStudent(student);
    }

    @Override
    public List<Student> getAllStudent() throws RemoteException {
       return dao.getAllStudent();
    }

    @Override
    public void updateStudent(Student student) throws RemoteException {
        dao.updateStudent(student);
    }

   

    @Override
    public void deleteCourse(Student student) throws RemoteException {
        dao.deleteStudent(student);
    }

    @Override
    public Student findStudent(String regNo) throws RemoteException {
     return dao.findStudent(regNo);
    }

    @Override
    public Student findStudentById(Integer id) throws RemoteException {
      return dao.findStudentById(id);
    }
    
}
