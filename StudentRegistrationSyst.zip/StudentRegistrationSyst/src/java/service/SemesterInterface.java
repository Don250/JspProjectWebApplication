/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import model.Course;
import model.Semester;

/**
 *
 * @author ndagi
 */
public interface SemesterInterface extends Remote {

    public boolean registerCourse(Semester semester) throws RemoteException;

    public Semester findSem(String name) throws RemoteException;

    public Semester findSemById(Integer id) throws RemoteException;

    public List<Semester> getAllSemesters() throws RemoteException;

    public void updateSemester(Semester semester) throws RemoteException;

    public void deleteSemester(Semester semester) throws RemoteException;
}
