/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import dao.TeacherDao;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import model.Teacher;

/**
 *
 * @author ndagi
 */
public class TeacherInterfaceImp extends UnicastRemoteObject implements TeacherInterface{

    public TeacherInterfaceImp() throws RemoteException {
        super();
    }
   
    TeacherDao dao=new TeacherDao();

    @Override
    public boolean registerTeacher(Teacher teacher) throws RemoteException {
       return dao.registerTeacher(teacher);
    }

    @Override
    public List<Teacher> getAllTeacher() throws RemoteException {
     return dao.getAllTeacher();
    }

    @Override
    public void updateTeacher(Teacher teacher) throws RemoteException {
    dao.updateTeacher(teacher);
    }

    @Override
    public Teacher findTeacher(String regNo) throws RemoteException {
      return dao.findTeacher(regNo);
    }

    @Override
    public void deleteTeacher(Teacher teacher) throws RemoteException {
    dao.deleteTeacher(teacher);
    }
    
}
