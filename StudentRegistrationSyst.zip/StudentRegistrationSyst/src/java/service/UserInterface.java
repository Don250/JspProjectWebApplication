/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import java.rmi.Remote;
import java.rmi.RemoteException;
import model.Users;

/**
 *
 * @author ndagi
 */
public interface UserInterface extends Remote{
    public boolean registerUser(Users user)throws RemoteException;
    public boolean userAuthentication(Users user)throws RemoteException;
    public void updateAuccount(Users user)throws RemoteException;
    public Users findByEmail(Users user)throws RemoteException;
    public void deleteUser(Users user)throws RemoteException;  
}
