/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

import model.Course;

/**
 *
 * @author ndagi
 */
public interface CourseInterface extends Remote {

    public boolean registerCourse(Course course) throws RemoteException;

    public List<Course> getAllCourses() throws RemoteException;

    public void updateCourse(Course course) throws RemoteException;

    public Course findCourse(String courseCode) throws RemoteException;

    public void deleteCourse(Course course) throws RemoteException;

}
