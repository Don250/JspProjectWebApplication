/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**
 *
 * @author ndagi
 */
@Entity
public class Semester implements Serializable {

    @Id
    @GeneratedValue
    private int id;
    @Column(unique = true)
    private String name;
    private String startDAte;
    private String endDate;
    @OneToMany(mappedBy = "semester",fetch = FetchType.EAGER)
    private List<StudentRegistration> studentRegistrations;

    public Semester() {
    }

    public Semester(int id) {
        this.id = id;
    }

    public Semester(int id, List<StudentRegistration> studentRegistrations,String name, String startDAte, String endDate) {
        this.id = id;
        this.name = name;
        this.startDAte = startDAte;
        this.endDate = endDate;
        this.studentRegistrations=studentRegistrations;
    }

    public List<StudentRegistration> getStudentRegistrations() {
        return studentRegistrations;
    }

    public void setStudentRegistrations(List<StudentRegistration> studentRegistrations) {
        this.studentRegistrations = studentRegistrations;
    }
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStartDAte() {
        return startDAte;
    }

    public void setStartDAte(String startDAte) {
        this.startDAte = startDAte;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public void clear() {
        this.setStartDAte("");
        this.setEndDate("");
        this.setName("");
    }

}
